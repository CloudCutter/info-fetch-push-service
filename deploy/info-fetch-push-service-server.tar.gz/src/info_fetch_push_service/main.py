from __future__ import annotations

import argparse
import json
import logging
import os
import signal
import subprocess
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

from .config import RuntimeConfigProvider, StaticSettings


def configure_logging() -> None:
    root = Path.cwd()
    log_dir = root / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / "service.log"

    formatter = logging.Formatter("%(asctime)s %(levelname)s %(name)s - %(message)s")
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)

    file_handler = RotatingFileHandler(
        log_path,
        maxBytes=2 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)

    root_logger = logging.getLogger()
    root_logger.handlers.clear()
    root_logger.setLevel(logging.INFO)
    root_logger.addHandler(stream_handler)
    root_logger.addHandler(file_handler)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="info-fetch-push",
        description="Fetch X posts, summarize them with DeepSeek, and push them to Feishu.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("init-runtime-config", help="Create a runtime config file if it does not exist.")
    subparsers.add_parser("show-config", help="Print the currently loaded runtime config.")
    subparsers.add_parser("login", help="Open a browser and save X login state locally.")
    subparsers.add_parser(
        "import-edge-session",
        help="Import X login cookies from the local Microsoft Edge profile into the Playwright session file.",
    )
    subparsers.add_parser("stop", help="Stop all background serve processes for this project.")
    subparsers.add_parser("run-once", help="Run one fetch/summarize/push cycle.")
    subparsers.add_parser("serve", help="Run the service in a loop.")

    return parser


def main() -> int:
    configure_logging()
    parser = build_parser()
    args = parser.parse_args()

    settings = StaticSettings.load()
    settings.ensure_directories()
    runtime_config_provider = RuntimeConfigProvider(
        config_path=settings.runtime_config_path,
        default_model=settings.deepseek_default_model,
    )

    if args.command == "init-runtime-config":
        created = runtime_config_provider.write_example()
        if created:
            print(f"Created runtime config at {settings.runtime_config_path}")
        else:
            print(f"Runtime config already exists at {settings.runtime_config_path}")
        return 0

    if args.command == "show-config":
        try:
            print(json.dumps(runtime_config_provider.describe(), ensure_ascii=False, indent=2))
            return 0
        except Exception as exc:
            print(str(exc), file=sys.stderr)
            return 1

    if args.command in {"login", "import-edge-session"}:
        from .fetchers.x_scraper import XTimelineScraper

        scraper = XTimelineScraper(
            storage_state_path=settings.x_login_state_path,
            headless=False,
            browser_channel=settings.x_browser_channel,
            system_user_data_path=settings.x_system_user_data_path,
            imported_profile_path=settings.x_imported_profile_path,
        )

        if args.command == "login":
            scraper.login()
            print(f"Saved X login state to {settings.x_login_state_path}")
            return 0

        if not sys.platform.startswith("win"):
            print(
                "import-edge-session is only supported on Windows with a local Microsoft Edge profile. "
                "On Linux servers, copy data/x-login-state.json from a machine that already exported it.",
                file=sys.stderr,
            )
            return 1

        count = scraper.import_edge_login_state()
        print(f"Imported {count} X-related cookies into {settings.x_login_state_path}")
        return 0

    if args.command == "stop":
        stopped = stop_background_service()
        print(f"Stopped {stopped} serve process(es)")
        return 0

    try:
        settings.validate_runtime_dependencies()
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    from .pipeline import Pipeline

    pipeline = Pipeline(settings, runtime_config_provider)
    try:
        if args.command == "run-once":
            pipeline.run_once()
            return 0
        if args.command == "serve":
            pipeline.serve_forever()
            return 0
    finally:
        pipeline.close()

    parser.print_help()
    return 1


def stop_background_service() -> int:
    if sys.platform.startswith("win"):
        script = (
            "$procs = Get-CimInstance Win32_Process | "
            "Where-Object { $_.Name -like 'python*' -and $_.CommandLine -like '*info_fetch_push_service.main*serve*' }; "
            "$count = @($procs).Count; "
            "foreach ($p in $procs) { Stop-Process -Id $p.ProcessId -Force }; "
            "Write-Output $count"
        )
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", script],
            capture_output=True,
            text=True,
            check=True,
            env=os.environ.copy(),
        )
        output = result.stdout.strip()
        return int(output) if output else 0

    result = subprocess.run(
        ["ps", "-eo", "pid=,args="],
        capture_output=True,
        text=True,
        check=True,
        env=os.environ.copy(),
    )
    current_pid = os.getpid()
    stopped = 0
    for line in result.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        pid_text, _, args = line.partition(" ")
        if not pid_text.isdigit():
            continue
        pid = int(pid_text)
        if pid == current_pid:
            continue
        if "info_fetch_push_service.main" not in args or "serve" not in args:
            continue
        os.kill(pid, signal.SIGTERM)
        stopped += 1
    return stopped


if __name__ == "__main__":
    raise SystemExit(main())
